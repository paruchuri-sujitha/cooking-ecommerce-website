// Import required packages
const express = require("express");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());

// Sample data (like a database for now)
let recipes = [
  { id: 1, name: "Pasta", ingredients: ["noodles", "sauce", "cheese"], steps: "Boil pasta, add sauce, mix cheese." },
  { id: 2, name: "Pizza", ingredients: ["dough", "sauce", "cheese"], steps: "Prepare base, spread sauce, add cheese, bake." }
];

// Home route
app.get("/", (req, res) => {
  res.send("🍳 Cooking Website API is running!");
});

// Get all recipes
app.get("/recipes", (req, res) => {
  res.json(recipes);
});

// Get a single recipe by ID
app.get("/recipes/:id", (req, res) => {
  const recipe = recipes.find(r => r.id === parseInt(req.params.id));
  if (!recipe) {
    return res.status(404).json({ message: "Recipe not found" });
  }
  res.json(recipe);
});

// Add a new recipe
app.post("/recipes", (req, res) => {
  const newRecipe = {
    id: recipes.length + 1,
    name: req.body.name,
    ingredients: req.body.ingredients,
    steps: req.body.steps
  };
  recipes.push(newRecipe);
  res.status(201).json(newRecipe);
});

// Start server
app.listen(PORT, () => {
  console.log(✅ Server running on http://localhost:${PORT});
});